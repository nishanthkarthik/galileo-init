#!/bin/bash
set -e
#set -x

#Galileo IP
GALILEO_IP="192.168.1.10"

#echo "Enter Galileo IP" 
#read GALILEO_IP

#Sync date to Galileo
echo "> setting date to galileo"
ssh root@$GALILEO_IP date -s @`( date -u +"%s" )`

#Kill all instances of node
echo "> killing all node instances on galileo"
ssh root@$GALILEO_IP killall node

#SSH to galileo and check if directory exists
echo "> directory check on galileo"
ssh root@$GALILEO_IP << EOF
	mkdir -p ~/node_deploy
EOF

#tar source files
tar cvf src.tar --exclude=node_modules *
scp src.tar root@$GALILEO_IP:node_deploy/

#untar inside galileo
echo "> extracting archive on galileo"
ssh root@$GALILEO_IP << EOF
	tar xvf ~/node_deploy/src.tar -C ~/node_deploy
EOF

echo "> deploy complete"